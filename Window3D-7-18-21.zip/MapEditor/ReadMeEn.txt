Controls:
Mouse Left Button - moving-allocate.
Mouse Right Button - to remove.
Mouse Middle Button  - create a new, combined with a "0" ... "9" in the mode of "Things" creates a new item.
"C" - clone sector.
"0" ... "9" - if you pressed Alt - line material, pressing Shift - sectors upper plane, Ctrl - bottom plane.
Shift or Ctrl + Up Arrow will move sector up or down.

Editor retains always test.gmap, before getting to the game can be renamed.
If the sector is moving (the door, the elevator), put a nonzero Tag, value of Action - how much it moves, down if necessary - a negative number.
To buttons control this sector - it put a Target, a sector at Tag.
One button can operate in several sectors.
One sector can be controlled by a few buttons.
Items placed in the mode of "Things", also have the Tag. If it is zero (the default), the object appears immediately, if not zero - the first press of a button.